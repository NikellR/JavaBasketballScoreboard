import java.sql.*;
import java.util.ArrayList;

public class DatabaseConnection {
    static ArrayList<BasketballGames> season = new ArrayList<>();

    public static ArrayList<BasketballGames> connect() {
        try {
            // Establish connection to the MySQL database:
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/finalproject_db", "root", "TheHeroicGamer!7");
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("select * from bball_games");

            while (resultSet.next()) {
                BasketballGames aSeason = new BasketballGames(resultSet.getInt(1), resultSet.getInt(2), resultSet.getInt(3),
                         resultSet.getInt(4), resultSet.getString(5), resultSet.getString(6), resultSet.getInt(7));
                season.add(aSeason);
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return season;
    }
}
