public class BasketballGames {

    int ID;
    int gameID;
    int Quarter;
    int myTeamPoints;
    String myTeam;
    String otherTeam;
    int otherTeamPoints;

    public BasketballGames() {

    }

    public BasketballGames(int ID, int gameID, int Quarter, int myTeamPoints, String myTeam, String otherTeam, int otherTeamPoints) {
        this.ID = ID;
        this.gameID = gameID;
        this.Quarter = Quarter;
        this.myTeamPoints = myTeamPoints;
        this.myTeam = myTeam;
        this.otherTeam = otherTeam;
        this.otherTeamPoints = otherTeamPoints;
    }

    public int getID() {
        return ID;
    }
    public void setID(int ID) {
        this.ID = ID;
    }

    public int getGameID() {
        return gameID;
    }
    public void setGameID(int GameID) {
        this.gameID = GameID;
    }

    public int getQuarter() {
        return Quarter;
    }
    public void setQuarter(int Quarter) {
        this.Quarter = Quarter;
    }

    public int getMyTeamPoints() {
        return myTeamPoints;
    }
    public void setMyTeamPoints(int myTeamPoints) {
        this.myTeamPoints = myTeamPoints;
    }

    public String getMyTeam() {
        return myTeam;
    }

    public String getOtherTeam() {
        return otherTeam;
    }
    public void setOtherTeam(String OtherTeam) {
        this.otherTeam = OtherTeam;
    }

    public int getOtherTeamPoints() {
        return otherTeamPoints;
    }
    public void setOtherTeamPoints(int otherTeamPoints) {
        this.otherTeamPoints = otherTeamPoints;
    }

    @Override
    public String toString() {
        return String.format("Entry: " + getID() + ", " + "Game: " + getGameID() + ", " + "Quarter: " + getQuarter() +
                ", " + "My Team Points: " + getMyTeamPoints() + ", " + "My Team Name: " + getMyTeam() + ", " + "Other Team Name: "
         + getOtherTeam() + ", " + "Other Team Points: " + getOtherTeamPoints());
    }
}
