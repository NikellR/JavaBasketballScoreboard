/* =============================================================

Author : Nikell Reed
Class : ITN261
Class Section : 201
Date : 12/2/2021
Assignment : Final Project

================================================================

Code adapted from:

Most of the code used is from various different modules in the D2L.
As well as other sites like geeksforgeeks.org.


================================================================*/

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.util.*;

public class DisplayMenu extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        // Create Pane:
        Pane firstWindow = new Pane();
        // Creating the background color for the menu screen:
        Stop[] stops = new Stop[] {new Stop(0, Color.BLACK), new Stop(1, Color.GOLD)};
        LinearGradient lg1 = new LinearGradient(0, 0, 1, 0, true, CycleMethod.NO_CYCLE, stops);
        Rectangle rg = new Rectangle(600, 200);
        firstWindow.getChildren().add(rg);
        rg.setFill(lg1);
        // Setting up label for menu screen:
        Label menuText = new Label();
        menuText.setText("The Knights Analytics Program");
        menuText.setFont(Font.font("Verdana", FontWeight.BOLD, FontPosture.REGULAR, 25));
        menuText.setTextFill(Color.WHITE);
        firstWindow.getChildren().add(menuText);
        menuText.setLayoutX(90);
        menuText.setLayoutY(30);
        // Create buttons to open other windows:
        Button changeWindow = new Button("Enter/Edit");
        Button changeWindow2 = new Button("View Analytics");
        firstWindow.getChildren().addAll(changeWindow, changeWindow2);
        changeWindow.setLayoutX(100);
        changeWindow.setLayoutY(111);
        changeWindow2.setLayoutX(400);
        changeWindow2.setLayoutY(110);
        // Setting the main scene:
        Scene firstScene = new Scene(firstWindow, 600, 200);
        primaryStage.setScene(firstScene);
        primaryStage.setTitle("First Window");
        primaryStage.show();

        // Button to open enter/edit screen:
        changeWindow.setOnMouseClicked(event -> {
            BorderPane layout = new BorderPane();
            try {
                ArrayList<BasketballGames> basketballGamesArrayList;
                // Connect DatabaseConnection to ArrayList:
                basketballGamesArrayList = DatabaseConnection.connect();
                ObservableList<BasketballGames> basketballGamesObservableList = FXCollections.observableArrayList();
                ListView<BasketballGames> gamesListView = new ListView<>();
                for (BasketballGames basketballGames : basketballGamesArrayList) {
                    basketballGamesObservableList.add(basketballGames);
                    gamesListView.getItems().add(basketballGames);
                }
                gamesListView.setPrefSize(420, 325);
                VBox list = new VBox(gamesListView);
                layout.setCenter(list);
                // Creating the various textfields and buttons to enter/edit:
                TextField entry = new TextField();
                TextField game = new TextField();
                TextField quarter = new TextField();
                TextField otherTeam = new TextField();
                TextField knightsPoints = new TextField();
                TextField otherTeamPoints = new TextField();
                Button submitEntry = new Button("Search By Entry ID");
                Button submitGame = new Button("Search By Game");
                Button submitQuarter = new Button("Search By Qtr");
                Button submitOtherTeam = new Button("Search By Other Team Name");
                Button submitKnightsPoints = new Button("Search By Knights Points Scored");
                Button submitOtherTeamPoints = new Button("Search By Other Team Points Scored");
                Button viewAll = new Button("View All");
                VBox textFields = new VBox(viewAll, entry, submitEntry, game, submitGame, quarter, submitQuarter, otherTeam,
                        submitOtherTeam, knightsPoints, submitKnightsPoints, otherTeamPoints, submitOtherTeamPoints);
                TextField pickGameText = new TextField();
                TextField pickQtrText = new TextField();
                Button editOtherTeamName = new Button("Edit Other Team Name");
                TextField editOtherNameText = new TextField();
                Button editKnightsPoints = new Button("Edit Knights Points");
                TextField editKnightsPointsText = new TextField();
                Button editOtherTeamPoints = new Button("Edit Other Team Points");
                TextField editOtherTeamPointsText = new TextField();
                Text pickText = new Text("Type Number Of Game Info To Change:");
                Text pickAQtrText = new Text("Type Number Of Qtr Info To Change:");
                VBox editButtons = new VBox(pickText, pickGameText, pickAQtrText, pickQtrText, editOtherTeamName, editOtherNameText, editKnightsPoints, editKnightsPointsText, editOtherTeamPoints, editOtherTeamPointsText);
                layout.setRight(editButtons);
                layout.setLeft(textFields);
                // Button to submit edit of other team name:
                editOtherTeamName.setOnMouseClicked(eventEditOtherName -> {
                    gamesListView.getItems().clear();
                    for (BasketballGames edit: basketballGamesObservableList) {
                        if (edit.getGameID() == Integer.parseInt(pickGameText.getText())) {
                            edit.setOtherTeam(editOtherNameText.getText());
                            gamesListView.getItems().add(edit);
                        }
                    }
                });
                // Button to submit edit of Knights points:
                editKnightsPoints.setOnMouseClicked(eventKnightsPt -> {
                    gamesListView.getItems().clear();
                    for (BasketballGames edit: basketballGamesObservableList) {
                        if (edit.getGameID() == Integer.parseInt(pickGameText.getText()) && edit.getQuarter() == Integer.parseInt(pickQtrText.getText())) {
                            edit.setMyTeamPoints(Integer.parseInt(editKnightsPointsText.getText()));
                            gamesListView.getItems().add(edit);
                        }
                    }
                });
                // Button to submit edit of other teams' points:
                editOtherTeamPoints.setOnMouseClicked(eventOtherPt -> {
                    gamesListView.getItems().clear();
                    for (BasketballGames edit: basketballGamesObservableList) {
                        if (edit.getGameID() == Integer.parseInt(pickGameText.getText()) && edit.getQuarter() == Integer.parseInt(pickQtrText.getText())) {
                            edit.setOtherTeamPoints(Integer.parseInt(editOtherTeamPointsText.getText()));
                            gamesListView.getItems().add(edit);
                        }
                    }
                });

                // Button to enter entry number:
                submitEntry.setOnMouseClicked(eventSubmit -> {
                    gamesListView.getItems().clear();
                    for (BasketballGames item: basketballGamesObservableList) {
                        if (item.getID() == Integer.parseInt(entry.getText())) {
                            gamesListView.getItems().add(item);
                        }
                    }
                });
                // Button to enter game number:
                submitGame.setOnMouseClicked(eventSubGame -> {
                    gamesListView.getItems().clear();
                    for (BasketballGames item: basketballGamesObservableList) {
                        if (item.getGameID() == Integer.parseInt(game.getText())) {
                            gamesListView.getItems().add(item);
                        }
                    }
                });
                // Button to enter Qtr number:
                submitQuarter.setOnMouseClicked(eventSubQtr -> {
                    gamesListView.getItems().clear();
                    for (BasketballGames item: basketballGamesObservableList) {
                        if (item.getQuarter() == Integer.parseInt(quarter.getText())) {
                            gamesListView.getItems().add(item);
                        }
                    }
                });
                // Button to enter other team name:
                submitOtherTeam.setOnMouseClicked(eventSubOther -> {
                    gamesListView.getItems().clear();
                    for (BasketballGames item: basketballGamesObservableList) {
                        if (Objects.equals(item.getOtherTeam(), otherTeam.getText())) {
                            gamesListView.getItems().add(item);
                        }
                    }
                });
                // Button to enter Knights points value:
                submitKnightsPoints.setOnMouseClicked(eventSubMyPt -> {
                    gamesListView.getItems().clear();
                    for (BasketballGames item: basketballGamesObservableList) {
                        if (item.getMyTeamPoints() == Integer.parseInt(knightsPoints.getText())) {
                            gamesListView.getItems().add(item);
                        }
                    }
                });
                // Button to enter other teams' points value:
                submitOtherTeamPoints.setOnMouseClicked(eventSubOtherPt -> {
                    gamesListView.getItems().clear();
                    for (BasketballGames item: basketballGamesObservableList) {
                        if (item.getOtherTeamPoints() == Integer.parseInt(otherTeamPoints.getText())) {
                            gamesListView.getItems().add(item);
                        }
                    }
                });
                // Button to view all stats:
                viewAll.setOnMouseClicked(eventViewAll -> {
                    gamesListView.getItems().clear();
                    for (BasketballGames item: basketballGamesObservableList) {
                        gamesListView.getItems().add(item);
                    }
                });

                Scene secondScene = new Scene(layout, 1140, 330);
                Stage secondStage = new Stage();
                secondStage.setScene(secondScene);
                secondStage.setTitle("Enter/Edit Window");
                secondStage.show();

            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        // Button to open analytics window:
        changeWindow2.setOnMouseClicked(event -> {
            BorderPane theLayout = new BorderPane();
            // Creating all the buttons to access each analytic:
            Button avg1 = new Button("Avg Of Q1");
            Button avg2 = new Button("Avg Of Q2");
            Button avg3 = new Button("Avg Of Q3");
            Button avg4 = new Button("Avg Of Q4");
            Button avgGame1 = new Button("Avg of Game 1");
            Button avgGame2 = new Button("Avg of Game 2");
            Button avgGame3 = new Button("Avg of Game 3");
            Button avgGame4 = new Button("Avg of Game 4");
            Button avgGame5 = new Button("Avg of Game 5");
            Button avgGame6 = new Button("Avg of Game 6");
            Button avgGame7 = new Button("Avg of Game 7");
            Button avgGame8 = new Button("Avg of Game 8");
            Button avgGame9 = new Button("Avg of Game 9");
            Button avgGame10 = new Button("Avg of Game 10");
            Button LowPoints = new Button("Lowest points");
            Button HighPoints = new Button("Highest points");

            try {
                ArrayList<BasketballGames> basketballGamesArrayList;
                // Connect DatabaseConnection to ArrayList:
                basketballGamesArrayList = DatabaseConnection.connect();
                ObservableList<BasketballGames> basketballGamesObservableList = FXCollections.observableArrayList();
                ListView<BasketballGames> gamesListView = new ListView<>();
                for (BasketballGames basketballGames : basketballGamesArrayList) {
                    basketballGamesObservableList.add(basketballGames);
                    gamesListView.getItems().add(basketballGames);
                }
                gamesListView.setPrefSize(600, 600);
                // Setting up all the Vboxs for buttons and textfields:
                VBox buttons = new VBox(avg1, avg2, avg3, avg4, avgGame1, avgGame2, avgGame3, avgGame4, avgGame5,
                        avgGame6, avgGame7, avgGame8, avgGame9, avgGame10, LowPoints, HighPoints);
                buttons.setPrefSize(150, 150);
                buttons.setPadding(new Insets(5, 5, 5, 5));
                buttons.setSpacing(10);

                VBox avgTextBox = new VBox();
                avgTextBox.setPrefSize(150, 150);
                avgTextBox.setPadding(new Insets(5, 5, 5, 25));
                avgTextBox.setSpacing(20);
                avgTextBox.setStyle("-fx-background-color: gold;");

                VBox avgGameBox = new VBox();
                avgGameBox.setPrefSize(150, 150);
                avgGameBox.setPadding(new Insets(5, 5, 5, 25));
                avgGameBox.setSpacing(20);
                avgGameBox.setStyle("-fx-background-color: gold;");

                VBox lowPoints = new VBox();
                lowPoints.setPrefSize(150, 150);
                lowPoints.setPadding(new Insets(5, 5, 5, 25));
                lowPoints.setStyle("-fx-background-color: gold;");

                VBox highPoints = new VBox();
                highPoints.setPrefSize(150, 150);
                highPoints.setPadding(new Insets(5, 5, 5, 25));
                highPoints.setStyle("-fx-background-color: gold;");
                // Setting up button to view Qtr 1 stats:
                avg1.setOnMouseClicked(event1 -> {
                    avgTextBox.getChildren().clear();
                    double sum = 0;
                    double sum1 = 0;
                    int count = 0;
                    int count1 = 0;
                    ArrayList<Integer> arrayList = new ArrayList<>();
                    ArrayList<Integer> arrayList1 = new ArrayList<>();
                    for (BasketballGames avg: basketballGamesObservableList) {
                        if (avg.getQuarter() == 1) {
                            int Q1arrayList;
                            Q1arrayList = avg.getMyTeamPoints();
                            arrayList.add(Q1arrayList);
                            for (int i: arrayList) {
                                sum += i;
                                count += 1;
                            }
                            int Q1arrayListOther;
                            Q1arrayListOther = avg.getOtherTeamPoints();
                            arrayList1.add(Q1arrayListOther);
                            for (int x: arrayList1) {
                                sum1 += x;
                                count1 += 1;
                            }
                        }
                    }
                    double diffPoints = sum - sum1;
                    double combineCount = count + count1;
                    double diffPointsTotal = diffPoints / combineCount;
                    double avgQ1 = sum / count;
                    double avgOtherQ1 = sum1 / count1;
                    Text avg1text = new Text("The Knights Scored An Average Of " + (String.format("%.2f", avgQ1)) + " For First Quarter Points");
                    Text avgOther1text = new Text("Other Teams Scored An Average Of " + (String.format("%.2f", avgOtherQ1)) + " Against The Knights In The First Quarter");
                    Text pointDiffText = new Text("The Point Differential For The First Quarter: " + (String.format("%.2f", diffPointsTotal)));
                    avgTextBox.getChildren().addAll(avg1text, avgOther1text, pointDiffText);
                    theLayout.setCenter(avgTextBox);
                });
                // Setting up button to view Qtr 2 stats:
                avg2.setOnMouseClicked(event2 -> {
                    avgTextBox.getChildren().clear();
                    double sum = 0;
                    double sum1 = 0;
                    int count = 0;
                    int count1 = 0;
                    ArrayList<Integer> arrayList = new ArrayList<>();
                    ArrayList<Integer> arrayList1 = new ArrayList<>();
                    for (BasketballGames avg: basketballGamesObservableList) {
                        if (avg.getQuarter() == 2) {
                            int Q2arrayList;
                            Q2arrayList = avg.getMyTeamPoints();
                            arrayList.add(Q2arrayList);
                            for (int i: arrayList) {
                                sum += i;
                                count += 1;
                            }
                            int Q2arrayListOther;
                            Q2arrayListOther = avg.getOtherTeamPoints();
                            arrayList1.add(Q2arrayListOther);
                            for (int x: arrayList1) {
                                sum1 += x;
                                count1 += 1;
                            }
                        }
                    }
                    double diffPoints = sum - sum1;
                    double combineCount = count + count1;
                    double diffPointsTotal = diffPoints / combineCount;
                    double avgQ2 = sum / count;
                    double avgOtherQ2 = sum1 / count1;
                    Text avg2text = new Text("The Knights Scored An Average Of " + (String.format("%.2f", avgQ2)) + " For Second Quarter Points");
                    Text avgOther2text = new Text("Other Teams Scored An Average Of " + (String.format("%.2f", avgOtherQ2)) + " Against The Knights In The Second Quarter");
                    Text pointDiffText = new Text("The Point Differential For The Second Quarter: " + (String.format("%.2f", diffPointsTotal)));
                    avgTextBox.getChildren().addAll(avg2text, avgOther2text, pointDiffText);
                    theLayout.setCenter(avgTextBox);
                });
                // Setting up button to view Qtr 3 stats:
                avg3.setOnMouseClicked(event3 -> {
                    avgTextBox.getChildren().clear();
                    double sum = 0;
                    double sum1 = 0;
                    int count = 0;
                    int count1 = 0;
                    ArrayList<Integer> arrayList = new ArrayList<>();
                    ArrayList<Integer> arrayList1 = new ArrayList<>();
                    for (BasketballGames avg: basketballGamesObservableList) {
                        if (avg.getQuarter() == 3) {
                            int Q3arrayList;
                            Q3arrayList = avg.getMyTeamPoints();
                            arrayList.add(Q3arrayList);
                            for (int i: arrayList) {
                                sum += i;
                                count += 1;
                            }
                            int Q3arrayListOther;
                            Q3arrayListOther = avg.getOtherTeamPoints();
                            arrayList1.add(Q3arrayListOther);
                            for (int x: arrayList1) {
                                sum1 += x;
                                count1 += 1;
                            }
                        }
                    }
                    double diffPoints = sum - sum1;
                    double combineCount = count + count1;
                    double diffPointsTotal = diffPoints / combineCount;
                    double avgQ3 = sum / count;
                    double avgOtherQ3 = sum1 / count1;
                    Text avg3text = new Text("The Knights Scored An Average Of " + (String.format("%.2f", avgQ3)) + " For Third Quarter Points");
                    Text avgOther3text = new Text("Other Teams Scored An Average Of " + (String.format("%.2f", avgOtherQ3)) + " Against The Knights In The Third Quarter");
                    Text pointDiffText = new Text("The Point Differential For The Third Quarter: " + (String.format("%.2f", diffPointsTotal)));
                    avgTextBox.getChildren().addAll(avg3text, avgOther3text, pointDiffText);
                    theLayout.setCenter(avgTextBox);
                });
                // Setting up button to view Qtr 4 stats:
                avg4.setOnMouseClicked(event4 -> {
                    avgTextBox.getChildren().clear();
                    double sum = 0;
                    double sum1 = 0;
                    int count = 0;
                    int count1 = 0;
                    ArrayList<Integer> arrayList = new ArrayList<>();
                    ArrayList<Integer> arrayList1 = new ArrayList<>();
                    for (BasketballGames avg: basketballGamesObservableList) {
                        if (avg.getQuarter() == 4) {
                            int Q4arrayList;
                            Q4arrayList = avg.getMyTeamPoints();
                            arrayList.add(Q4arrayList);
                            for (int i: arrayList) {
                                sum += i;
                                count += 1;
                            }
                            int Q4arrayListOther;
                            Q4arrayListOther = avg.getOtherTeamPoints();
                            arrayList1.add(Q4arrayListOther);
                            for (int x: arrayList1) {
                                sum1 += x;
                                count1 += 1;
                            }
                        }
                    }
                    double diffPoints = sum - sum1;
                    double combineCount = count + count1;
                    double diffPointsTotal = diffPoints / combineCount;
                    double avgQ4 = sum / count;
                    double avgOtherQ4 = sum1 / count1;
                    Text avg4text = new Text("The Knights Scored An Average Of " + (String.format("%.2f", avgQ4)) + " For Fourth Quarter Points");
                    Text avgOther4text = new Text("Other Teams Scored An Average Of " + (String.format("%.2f", avgOtherQ4)) + " Against The Knights In The Fourth Quarter");
                    Text pointDiffText = new Text("The Point Differential For The Fourth Quarter: "  + (String.format("%.2f", diffPointsTotal)));
                    avgTextBox.getChildren().addAll(avg4text, avgOther4text, pointDiffText);
                    theLayout.setCenter(avgTextBox);
                });
                // Setting up button to view game 1 stats:
                avgGame1.setOnMouseClicked(eventG1 -> {
                    avgGameBox.getChildren().clear();
                    double sum = 0;
                    double sum1 = 0;
                    int count = 0;
                    int count1 = 0;
                    ArrayList<Integer> gameList = new ArrayList<>();
                    ArrayList<Integer> gameListOther = new ArrayList<>();
                    for (BasketballGames games: basketballGamesObservableList) {
                        if (games.getGameID() == 1) {
                            int game;
                            game = games.getMyTeamPoints();
                            gameList.add(game);
                            for (int i: gameList) {
                                sum += i;
                                count += 1;
                            }

                            int gameOther;
                            gameOther = games.getOtherTeamPoints();
                            gameListOther.add(gameOther);
                            for (int x: gameListOther) {
                                sum1 += x;
                                count1 += 1;
                            }
                        }
                    }
                    // Getting each half stats
                    int firstHalf = gameList.get(0) + gameList.get(1);
                    int secondHalf = gameList.get(2) + gameList.get(3);
                    int firstHalfOther = gameListOther.get(0) + gameListOther.get(1);
                    int secondHalfOther = gameListOther.get(2) + gameListOther.get(3);
                    int firstHalfOtherAvg = firstHalfOther / 2;
                    int secondHalfOtherAvg = secondHalfOther / 2;
                    double halfOtherAvg = firstHalfOtherAvg + secondHalfOtherAvg / count1;
                    int firstHalfAvg = firstHalf / 2;
                    int secondHalfAvg = secondHalf / 2;
                    double halfAvg = firstHalfAvg + secondHalfAvg / count;

                    double diffPoints = sum - sum1;
                    double combineCount = count + count1;
                    double diffPointsTotal = diffPoints / combineCount;
                    double gameAvg = sum / count;
                    double gameOtherAvg = sum1 / count1;

                    Text gameAvgText = new Text("The Knights Scored An Average Of " + (String.format("%.2f", gameAvg)) + " In Game 1");
                    Text gameOtherText = new Text("The Other Team Scored An Average Of " + (String.format("%.2f", gameOtherAvg)) + " In Game 1");
                    Text halfAvgText = new Text("The Knights Scored An Average Of " + (String.format("%.2f", halfAvg)) + " In Each Half Of Game 1");
                    Text halfAvgOtherText = new Text("The Other Team Scored An Average Of " + (String.format("%.2f", halfOtherAvg)) + " In Each Half Of Game 1");
                    Text pointDiffText = new Text("The Point Differential For Game 1: " + (String.format("%.2f", diffPointsTotal)));
                    avgGameBox.getChildren().addAll(gameAvgText, gameOtherText, halfAvgText, halfAvgOtherText, pointDiffText);
                    theLayout.setCenter(avgGameBox);
                });
                // Setting up button to view game 2 stats:
                avgGame2.setOnMouseClicked(eventG2 -> {
                    avgGameBox.getChildren().clear();
                    double sum = 0;
                    double sum1 = 0;
                    int count = 0;
                    int count1 = 0;
                    ArrayList<Integer> gameList = new ArrayList<>();
                    ArrayList<Integer> gameListOther = new ArrayList<>();
                    for (BasketballGames games: basketballGamesObservableList) {
                        if (games.getGameID() == 2) {
                            int game;
                            game = games.getMyTeamPoints();
                            gameList.add(game);
                            for (int i: gameList) {
                                sum += i;
                                count += 1;

                            }
                            int gameOther;
                            gameOther = games.getOtherTeamPoints();
                            gameListOther.add(gameOther);
                            for (int x: gameListOther) {
                                sum1 += x;
                                count1 += 1;
                            }
                        }
                    }
                    int firstHalf = gameList.get(0) + gameList.get(1);
                    int secondHalf = gameList.get(2) + gameList.get(3);
                    int firstHalfOther = gameListOther.get(0) + gameListOther.get(1);
                    int secondHalfOther = gameListOther.get(2) + gameListOther.get(3);
                    int firstHalfOtherAvg = firstHalfOther / 2;
                    int secondHalfOtherAvg = secondHalfOther / 2;
                    double halfOtherAvg = firstHalfOtherAvg + secondHalfOtherAvg / count1;
                    int firstHalfAvg = firstHalf / 2;
                    int secondHalfAvg = secondHalf / 2;
                    double halfAvg = firstHalfAvg + secondHalfAvg / count;
                    double diffPoints = sum - sum1;
                    double combineCount = count + count1;
                    double diffPointsTotal = diffPoints / combineCount;
                    double gameAvg = sum / count;
                    double gameOtherAvg = sum1 / count1;
                    Text gameAvgText = new Text("The Knights Scored An Average Of " + (String.format("%.2f", gameAvg)) + " In Game 2");
                    Text gameOtherText = new Text("The Other Team Scored An Average Of " + (String.format("%.2f", gameOtherAvg)) + " In Game 2");
                    Text halfAvgText = new Text("The Knights Scored An Average Of " + (String.format("%.2f", halfAvg)) + " In Each Half Of Game 2");
                    Text halfAvgOtherText = new Text("The Other Team Scored An Average Of " + (String.format("%.2f", halfOtherAvg)) + " In Each Half Of Game 2");
                    Text pointDiffText = new Text("The Point Differential For Game 2: " + (String.format("%.2f", diffPointsTotal)));
                    avgGameBox.getChildren().addAll(gameAvgText, gameOtherText, halfAvgText, halfAvgOtherText, pointDiffText);
                    theLayout.setCenter(avgGameBox);
                });
                // Setting up button to view game 3 stats:
                avgGame3.setOnMouseClicked(eventG3 -> {
                    avgGameBox.getChildren().clear();
                    double sum = 0;
                    double sum1 = 0;
                    int count = 0;
                    int count1 = 0;
                    ArrayList<Integer> gameList = new ArrayList<>();
                    ArrayList<Integer> gameListOther = new ArrayList<>();
                    for (BasketballGames games: basketballGamesObservableList) {
                        if (games.getGameID() == 3) {
                            int game;
                            game = games.getMyTeamPoints();
                            gameList.add(game);
                            for (int i: gameList) {
                                sum += i;
                                count += 1;

                            }
                            int gameOther;
                            gameOther = games.getOtherTeamPoints();
                            gameListOther.add(gameOther);
                            for (int x: gameListOther) {
                                sum1 += x;
                                count1 += 1;
                            }
                        }
                    }
                    int firstHalf = gameList.get(0) + gameList.get(1);
                    int secondHalf = gameList.get(2) + gameList.get(3);
                    int firstHalfOther = gameListOther.get(0) + gameListOther.get(1);
                    int secondHalfOther = gameListOther.get(2) + gameListOther.get(3);
                    int firstHalfOtherAvg = firstHalfOther / 2;
                    int secondHalfOtherAvg = secondHalfOther / 2;
                    double halfOtherAvg = firstHalfOtherAvg + secondHalfOtherAvg / count1;
                    int firstHalfAvg = firstHalf / 2;
                    int secondHalfAvg = secondHalf / 2;
                    double halfAvg = firstHalfAvg + secondHalfAvg / count;
                    double diffPoints = sum - sum1;
                    double combineCount = count + count1;
                    double diffPointsTotal = diffPoints / combineCount;
                    double gameAvg = sum / count;
                    double gameOtherAvg = sum1 / count1;
                    Text gameAvgText = new Text("The Knights Scored An Average Of " + (String.format("%.2f", gameAvg)) + " In Game 3");
                    Text gameOtherText = new Text("The Other Team Scored An Average Of " + (String.format("%.2f", gameOtherAvg)) + " In Game 3");
                    Text halfAvgText = new Text("The Knights Scored An Average Of " + (String.format("%.2f", halfAvg)) + " In Each Half Of Game 3");
                    Text halfAvgOtherText = new Text("The Other Team Scored An Average Of " + (String.format("%.2f", halfOtherAvg)) + " In Each Half Of Game 3");
                    Text pointDiffText = new Text("The Point Differential For Game 3: " + (String.format("%.2f", diffPointsTotal)));
                    avgGameBox.getChildren().addAll(gameAvgText, gameOtherText, halfAvgText, halfAvgOtherText, pointDiffText);
                    theLayout.setCenter(avgGameBox);
                });
                // Setting up button to view game 4 stats:
                avgGame4.setOnMouseClicked(eventG4 -> {
                    avgGameBox.getChildren().clear();
                    double sum = 0;
                    double sum1 = 0;
                    int count = 0;
                    int count1 = 0;
                    ArrayList<Integer> gameList = new ArrayList<>();
                    ArrayList<Integer> gameListOther = new ArrayList<>();
                    for (BasketballGames games: basketballGamesObservableList) {
                        if (games.getGameID() == 4) {
                            int game;
                            game = games.getMyTeamPoints();
                            gameList.add(game);
                            for (int i: gameList) {
                                sum += i;
                                count += 1;

                            }
                            int gameOther;
                            gameOther = games.getOtherTeamPoints();
                            gameListOther.add(gameOther);
                            for (int x: gameListOther) {
                                sum1 += x;
                                count1 += 1;
                            }
                        }
                    }
                    int firstHalf = gameList.get(0) + gameList.get(1);
                    int secondHalf = gameList.get(2) + gameList.get(3);
                    int firstHalfOther = gameListOther.get(0) + gameListOther.get(1);
                    int secondHalfOther = gameListOther.get(2) + gameListOther.get(3);
                    int firstHalfOtherAvg = firstHalfOther / 2;
                    int secondHalfOtherAvg = secondHalfOther / 2;
                    double halfOtherAvg = firstHalfOtherAvg + secondHalfOtherAvg / count1;
                    int firstHalfAvg = firstHalf / 2;
                    int secondHalfAvg = secondHalf / 2;
                    double halfAvg = firstHalfAvg + secondHalfAvg / count;
                    double diffPoints = sum - sum1;
                    double combineCount = count + count1;
                    double diffPointsTotal = diffPoints / combineCount;
                    double gameAvg = sum / count;
                    double gameOtherAvg = sum1 / count1;
                    Text gameAvgText = new Text("The Knights Scored An Average Of " + (String.format("%.2f", gameAvg)) + " In Game 4");
                    Text gameOtherText = new Text("The Other Team Scored An Average Of " + (String.format("%.2f", gameOtherAvg)) + " In Game 4");
                    Text halfAvgText = new Text("The Knights Scored An Average Of " + (String.format("%.2f", halfAvg)) + " In Each Half Of Game 4");
                    Text halfAvgOtherText = new Text("The Other Team Scored An Average Of " + (String.format("%.2f", halfOtherAvg)) + " In Each Half Of Game 4");
                    Text pointDiffText = new Text("The Point Differential For Game 4: " + (String.format("%.2f", diffPointsTotal)));
                    avgGameBox.getChildren().addAll(gameAvgText, gameOtherText, halfAvgText, halfAvgOtherText, pointDiffText);
                    theLayout.setCenter(avgGameBox);
                });
                // Setting up button to view game 5 stats:
                avgGame5.setOnMouseClicked(eventG5 -> {
                    avgGameBox.getChildren().clear();
                    double sum = 0;
                    double sum1 = 0;
                    int count = 0;
                    int count1 = 0;
                    ArrayList<Integer> gameList = new ArrayList<>();
                    ArrayList<Integer> gameListOther = new ArrayList<>();
                    for (BasketballGames games: basketballGamesObservableList) {
                        if (games.getGameID() == 5) {
                            int game;
                            game = games.getMyTeamPoints();
                            gameList.add(game);
                            for (int i: gameList) {
                                sum += i;
                                count += 1;

                            }
                            int gameOther;
                            gameOther = games.getOtherTeamPoints();
                            gameListOther.add(gameOther);
                            for (int x: gameListOther) {
                                sum1 += x;
                                count1 += 1;
                            }
                        }
                    }
                    int firstHalf = gameList.get(0) + gameList.get(1);
                    int secondHalf = gameList.get(2) + gameList.get(3);
                    int firstHalfOther = gameListOther.get(0) + gameListOther.get(1);
                    int secondHalfOther = gameListOther.get(2) + gameListOther.get(3);
                    int firstHalfOtherAvg = firstHalfOther / 2;
                    int secondHalfOtherAvg = secondHalfOther / 2;
                    double halfOtherAvg = firstHalfOtherAvg + secondHalfOtherAvg / count1;
                    int firstHalfAvg = firstHalf / 2;
                    int secondHalfAvg = secondHalf / 2;
                    double halfAvg = firstHalfAvg + secondHalfAvg / count;
                    double diffPoints = sum - sum1;
                    double combineCount = count + count1;
                    double diffPointsTotal = diffPoints / combineCount;
                    double gameAvg = sum / count;
                    double gameOtherAvg = sum1 / count1;
                    Text gameAvgText = new Text("The Knights Scored An Average Of " + (String.format("%.2f", gameAvg)) + " In Game 5");
                    Text gameOtherText = new Text("The Other Team Scored An Average Of " + (String.format("%.2f", gameOtherAvg)) + " In Game 5");
                    Text halfAvgText = new Text("The Knights Scored An Average Of " + (String.format("%.2f", halfAvg)) + " In Each Half Of Game 5");
                    Text halfAvgOtherText = new Text("The Other Team Scored An Average Of " + (String.format("%.2f", halfOtherAvg)) + " In Each Half Of Game 5");
                    Text pointDiffText = new Text("The Point Differential For Game 5: " + (String.format("%.2f", diffPointsTotal)));
                    avgGameBox.getChildren().addAll(gameAvgText, gameOtherText, halfAvgText, halfAvgOtherText, pointDiffText);
                    theLayout.setCenter(avgGameBox);
                });
                // Setting up button to view game 6 stats:
                avgGame6.setOnMouseClicked(eventG6 -> {
                    avgGameBox.getChildren().clear();
                    double sum = 0;
                    double sum1 = 0;
                    int count = 0;
                    int count1 = 0;
                    ArrayList<Integer> gameList = new ArrayList<>();
                    ArrayList<Integer> gameListOther = new ArrayList<>();
                    for (BasketballGames games: basketballGamesObservableList) {
                        if (games.getGameID() == 6) {
                            int game;
                            game = games.getMyTeamPoints();
                            gameList.add(game);
                            for (int i: gameList) {
                                sum += i;
                                count += 1;

                            }
                            int gameOther;
                            gameOther = games.getOtherTeamPoints();
                            gameListOther.add(gameOther);
                            for (int x: gameListOther) {
                                sum1 += x;
                                count1 += 1;
                            }
                        }
                    }
                    int firstHalf = gameList.get(0) + gameList.get(1);
                    int secondHalf = gameList.get(2) + gameList.get(3);
                    int firstHalfOther = gameListOther.get(0) + gameListOther.get(1);
                    int secondHalfOther = gameListOther.get(2) + gameListOther.get(3);
                    int firstHalfOtherAvg = firstHalfOther / 2;
                    int secondHalfOtherAvg = secondHalfOther / 2;
                    double halfOtherAvg = firstHalfOtherAvg + secondHalfOtherAvg / count1;
                    int firstHalfAvg = firstHalf / 2;
                    int secondHalfAvg = secondHalf / 2;
                    double halfAvg = firstHalfAvg + secondHalfAvg / count;
                    double diffPoints = sum - sum1;
                    double combineCount = count + count1;
                    double diffPointsTotal = diffPoints / combineCount;
                    double gameAvg = sum / count;
                    double gameOtherAvg = sum1 / count1;
                    Text gameAvgText = new Text("The Knights Scored An Average Of " + (String.format("%.2f", gameAvg)) + " In Game 6");
                    Text gameOtherText = new Text("The Other Team Scored An Average Of " + (String.format("%.2f", gameOtherAvg)) + " In Game 6");
                    Text halfAvgText = new Text("The Knights Scored An Average Of " + (String.format("%.2f", halfAvg)) + " In Each Half Of Game 6");
                    Text halfAvgOtherText = new Text("The Other Team Scored An Average Of " + (String.format("%.2f", halfOtherAvg)) + " In Each Half Of Game 6");
                    Text pointDiffText = new Text("The Point Differential For Game 6: " + (String.format("%.2f", diffPointsTotal)));
                    avgGameBox.getChildren().addAll(gameAvgText, gameOtherText, halfAvgText, halfAvgOtherText, pointDiffText);
                    theLayout.setCenter(avgGameBox);
                });
                // Setting up button to view game 7 stats:
                avgGame7.setOnMouseClicked(eventG7 -> {
                    avgGameBox.getChildren().clear();
                    double sum = 0;
                    double sum1 = 0;
                    int count = 0;
                    int count1 = 0;
                    ArrayList<Integer> gameList = new ArrayList<>();
                    ArrayList<Integer> gameListOther = new ArrayList<>();
                    for (BasketballGames games: basketballGamesObservableList) {
                        if (games.getGameID() == 7) {
                            int game;
                            game = games.getMyTeamPoints();
                            gameList.add(game);
                            for (int i: gameList) {
                                sum += i;
                                count += 1;

                            }
                            int gameOther;
                            gameOther = games.getOtherTeamPoints();
                            gameListOther.add(gameOther);
                            for (int x: gameListOther) {
                                sum1 += x;
                                count1 += 1;
                            }
                        }
                    }
                    int firstHalf = gameList.get(0) + gameList.get(1);
                    int secondHalf = gameList.get(2) + gameList.get(3);
                    int firstHalfOther = gameListOther.get(0) + gameListOther.get(1);
                    int secondHalfOther = gameListOther.get(2) + gameListOther.get(3);
                    int firstHalfOtherAvg = firstHalfOther / 2;
                    int secondHalfOtherAvg = secondHalfOther / 2;
                    double halfOtherAvg = firstHalfOtherAvg + secondHalfOtherAvg / count1;
                    int firstHalfAvg = firstHalf / 2;
                    int secondHalfAvg = secondHalf / 2;
                    double halfAvg = firstHalfAvg + secondHalfAvg / count;
                    double diffPoints = sum - sum1;
                    double combineCount = count + count1;
                    double diffPointsTotal = diffPoints / combineCount;
                    double gameAvg = sum / count;
                    double gameOtherAvg = sum1 / count1;
                    Text gameAvgText = new Text("The Knights Scored An Average Of " + (String.format("%.2f", gameAvg)) + " In Game 7");
                    Text gameOtherText = new Text("The Other Team Scored An Average Of " + (String.format("%.2f", gameOtherAvg)) + " In Game 7");
                    Text halfAvgText = new Text("The Knights Scored An Average Of " + (String.format("%.2f", halfAvg)) + " In Each Half Of Game 7");
                    Text halfAvgOtherText = new Text("The Other Team Scored An Average Of " + (String.format("%.2f", halfOtherAvg)) + " In Each Half Of Game 7");
                    Text pointDiffText = new Text("The Point Differential For Game 7: " + (String.format("%.2f", diffPointsTotal)));
                    avgGameBox.getChildren().addAll(gameAvgText, gameOtherText, halfAvgText, halfAvgOtherText, pointDiffText);
                    theLayout.setCenter(avgGameBox);
                });
                // Setting up button to view game 8 stats:
                avgGame8.setOnMouseClicked(eventG8 -> {
                    avgGameBox.getChildren().clear();
                    double sum = 0;
                    double sum1 = 0;
                    int count = 0;
                    int count1 = 0;
                    ArrayList<Integer> gameList = new ArrayList<>();
                    ArrayList<Integer> gameListOther = new ArrayList<>();
                    for (BasketballGames games: basketballGamesObservableList) {
                        if (games.getGameID() == 8) {
                            int game;
                            game = games.getMyTeamPoints();
                            gameList.add(game);
                            for (int i: gameList) {
                                sum += i;
                                count += 1;

                            }
                            int gameOther;
                            gameOther = games.getOtherTeamPoints();
                            gameListOther.add(gameOther);
                            for (int x: gameListOther) {
                                sum1 += x;
                                count1 += 1;
                            }
                        }
                    }
                    int firstHalf = gameList.get(0) + gameList.get(1);
                    int secondHalf = gameList.get(2) + gameList.get(3);
                    int firstHalfOther = gameListOther.get(0) + gameListOther.get(1);
                    int secondHalfOther = gameListOther.get(2) + gameListOther.get(3);
                    int firstHalfOtherAvg = firstHalfOther / 2;
                    int secondHalfOtherAvg = secondHalfOther / 2;
                    double halfOtherAvg = firstHalfOtherAvg + secondHalfOtherAvg / count1;
                    int firstHalfAvg = firstHalf / 2;
                    int secondHalfAvg = secondHalf / 2;
                    double halfAvg = firstHalfAvg + secondHalfAvg / count;
                    double diffPoints = sum - sum1;
                    double combineCount = count + count1;
                    double diffPointsTotal = diffPoints / combineCount;
                    double gameAvg = sum / count;
                    double gameOtherAvg = sum1 / count1;
                    Text gameAvgText = new Text("The Knights Scored An Average Of " + (String.format("%.2f", gameAvg)) + " In Game 8");
                    Text gameOtherText = new Text("The Other Team Scored An Average Of " + (String.format("%.2f", gameOtherAvg)) + " In Game 8");
                    Text halfAvgText = new Text("The Knights Scored An Average Of " + (String.format("%.2f", halfAvg)) + " In Each Half Of Game 8");
                    Text halfAvgOtherText = new Text("The Other Team Scored An Average Of " + (String.format("%.2f", halfOtherAvg)) + " In Each Half Of Game 8");
                    Text pointDiffText = new Text("The Point Differential For Game 8: " + (String.format("%.2f", diffPointsTotal)));
                    avgGameBox.getChildren().addAll(gameAvgText, gameOtherText, halfAvgText, halfAvgOtherText, pointDiffText);
                    theLayout.setCenter(avgGameBox);
                });
                // Setting up button to view game 9 stats:
                avgGame9.setOnMouseClicked(eventG9 -> {
                    avgGameBox.getChildren().clear();
                    double sum = 0;
                    double sum1 = 0;
                    int count = 0;
                    int count1 = 0;
                    ArrayList<Integer> gameList = new ArrayList<>();
                    ArrayList<Integer> gameListOther = new ArrayList<>();
                    for (BasketballGames games: basketballGamesObservableList) {
                        if (games.getGameID() == 9) {
                            int game;
                            game = games.getMyTeamPoints();
                            gameList.add(game);
                            for (int i: gameList) {
                                sum += i;
                                count += 1;

                            }
                            int gameOther;
                            gameOther = games.getOtherTeamPoints();
                            gameListOther.add(gameOther);
                            for (int x: gameListOther) {
                                sum1 += x;
                                count1 += 1;
                            }
                        }
                    }
                    int firstHalf = gameList.get(0) + gameList.get(1);
                    int secondHalf = gameList.get(2) + gameList.get(3);
                    int firstHalfOther = gameListOther.get(0) + gameListOther.get(1);
                    int secondHalfOther = gameListOther.get(2) + gameListOther.get(3);
                    int firstHalfOtherAvg = firstHalfOther / 2;
                    int secondHalfOtherAvg = secondHalfOther / 2;
                    double halfOtherAvg = firstHalfOtherAvg + secondHalfOtherAvg / count1;
                    int firstHalfAvg = firstHalf / 2;
                    int secondHalfAvg = secondHalf / 2;
                    double halfAvg = firstHalfAvg + secondHalfAvg / count;
                    double diffPoints = sum - sum1;
                    double combineCount = count + count1;
                    double diffPointsTotal = diffPoints / combineCount;
                    double gameAvg = sum / count;
                    double gameOtherAvg = sum1 / count1;
                    Text gameAvgText = new Text("The Knights Scored An Average Of " + (String.format("%.2f", gameAvg)) + " In Game 9");
                    Text gameOtherText = new Text("The Other Team Scored An Average Of " + (String.format("%.2f", gameOtherAvg)) + " In Game 9");
                    Text halfAvgText = new Text("The Knights Scored An Average Of " + (String.format("%.2f", halfAvg)) + " In Each Half Of Game 9");
                    Text halfAvgOtherText = new Text("The Other Team Scored An Average Of " + (String.format("%.2f", halfOtherAvg)) + " In Each Half Of Game 9");
                    Text pointDiffText = new Text("The Point Differential For Game 9: " + (String.format("%.2f", diffPointsTotal)));
                    avgGameBox.getChildren().addAll(gameAvgText, gameOtherText, halfAvgText, halfAvgOtherText, pointDiffText);
                    theLayout.setCenter(avgGameBox);
                });
                // Setting up button to view game 10 stats:
                avgGame10.setOnMouseClicked(eventG10 -> {
                    avgGameBox.getChildren().clear();
                    double sum = 0;
                    double sum1 = 0;
                    int count = 0;
                    int count1 = 0;
                    ArrayList<Integer> gameList = new ArrayList<>();
                    ArrayList<Integer> gameListOther = new ArrayList<>();
                    for (BasketballGames games: basketballGamesObservableList) {
                        if (games.getGameID() == 10) {
                            int game;
                            game = games.getMyTeamPoints();
                            gameList.add(game);
                            for (int i: gameList) {
                                sum += i;
                                count += 1;

                            }
                            int gameOther;
                            gameOther = games.getOtherTeamPoints();
                            gameListOther.add(gameOther);
                            for (int x: gameListOther) {
                                sum1 += x;
                                count1 += 1;
                            }
                        }
                    }
                    int firstHalf = gameList.get(0) + gameList.get(1);
                    int secondHalf = gameList.get(2) + gameList.get(3);
                    int firstHalfOther = gameListOther.get(0) + gameListOther.get(1);
                    int secondHalfOther = gameListOther.get(2) + gameListOther.get(3);
                    int firstHalfOtherAvg = firstHalfOther / 2;
                    int secondHalfOtherAvg = secondHalfOther / 2;
                    double halfOtherAvg = firstHalfOtherAvg + secondHalfOtherAvg / count1;
                    int firstHalfAvg = firstHalf / 2;
                    int secondHalfAvg = secondHalf / 2;
                    double halfAvg = firstHalfAvg + secondHalfAvg / count;
                    double diffPoints = sum - sum1;
                    double combineCount = count + count1;
                    double diffPointsTotal = diffPoints / combineCount;
                    double gameAvg = sum / count;
                    double gameOtherAvg = sum1 / count1;
                    Text gameAvgText = new Text("The Knights Scored An Average Of " + (String.format("%.2f", gameAvg)) + " In Game 10");
                    Text gameOtherText = new Text("The Other Team Scored An Average Of " + (String.format("%.2f", gameOtherAvg)) + " In Game 10");
                    Text halfAvgText = new Text("The Knights Scored An Average Of " + (String.format("%.2f", halfAvg)) + " In Each Half Of Game 10");
                    Text halfAvgOtherText = new Text("The Other Team Scored An Average Of " + (String.format("%.2f", halfOtherAvg)) + " In Each Half Of Game 10");
                    Text pointDiffText = new Text("The Point Differential For Game 10: " + (String.format("%.2f", diffPointsTotal)));
                    avgGameBox.getChildren().addAll(gameAvgText, gameOtherText, halfAvgText, halfAvgOtherText, pointDiffText);
                    theLayout.setCenter(avgGameBox);
                });
                // Setting up button to view the lowest points scored in any Qtr:
                LowPoints.setOnMouseClicked(eventLow -> {
                    lowPoints.getChildren().clear();
                    ArrayList<Integer> lowPointsList = new ArrayList<>();
                    for (BasketballGames low: basketballGamesObservableList) {
                        int lowPt;
                        int otherLowPt;
                        lowPt = low.getMyTeamPoints();
                        otherLowPt = low.getOtherTeamPoints();
                        lowPointsList.add(lowPt);
                        lowPointsList.add(otherLowPt);
                    }
                    int lowCollect = Collections.min(lowPointsList);
                    Text lowPointText = new Text("The lowest total points in any quarter was " + lowCollect);
                    lowPoints.getChildren().add(lowPointText);
                    theLayout.setCenter(lowPoints);
                });
                // Setting up button to view the highest points scored in any Qtr:
                HighPoints.setOnMouseClicked(eventHigh -> {
                    highPoints.getChildren().clear();
                    ArrayList<Integer> highPointsList = new ArrayList<>();
                    for (BasketballGames high: basketballGamesObservableList) {
                        int highPt;
                        int otherHighPt;
                        highPt = high.getMyTeamPoints();
                        otherHighPt = high.getOtherTeamPoints();
                        highPointsList.add(highPt);
                        highPointsList.add(otherHighPt);
                    }
                    int highCollect = Collections.max(highPointsList);
                    Text highPointText = new Text("The highest total points in any quarter was " + highCollect);
                    highPoints.getChildren().add(highPointText);
                    theLayout.setCenter(highPoints);
                });
                // Setting up scene:
                theLayout.setLeft(buttons);
                theLayout.setStyle("-fx-background-color: black;");
                Scene secondscene = new Scene(theLayout, 650, 570);
                Stage secondstage = new Stage();
                secondstage.setScene(secondscene);
                secondstage.setTitle("Analytics");
                secondstage.show();

            } catch (Exception e) {
                e.printStackTrace();
            }
        });

    }
}
